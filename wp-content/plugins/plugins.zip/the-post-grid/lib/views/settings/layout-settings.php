<?php

global $rtTPG;
echo $rtTPG->rtFieldGenerator($rtTPG->rtTPGLayoutSettingFields(), true);
