<?php

global $rtTPG;
echo $rtTPG->rtFieldGenerator($rtTPG->rtTPGStyleFields(), true);
